import json
from database import get_connection


def lambda_handler(event, context):

    try:
        body = json.loads(event.get("body", "{}"))

        # ---------- Validation ----------
        if not body.get("state_name"):
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "message": "State name required"
                })
            }

        if not body.get("country_id"):
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "message": "Country required"
                })
            }

        conn = get_connection()
        cursor = conn.cursor()

        query = """
            INSERT INTO states (state_name, country_id)
            VALUES (%s,%s)
        """

        cursor.execute(
            query,
            (
                body.get("state_name"),
                body.get("country_id")
            )
        )

        conn.commit()

        cursor.close()
        conn.close()

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "State created successfully"
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps(str(e))
        }
if __name__ == "__main__":

    event = {
        "body": json.dumps({
            "state_name": "Kerala",
            "country_id": 3
        })
    }

    print(lambda_handler(event, None))