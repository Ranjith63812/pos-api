import json
from database import get_connection


def lambda_handler(event, context):

    request_body = json.loads(event.get("body", "{}"))

    if not request_body.get("id"):
        return {
            "statusCode": 400,
            "body": json.dumps({
                "message": "Customer ID required"
            })
        }

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        UPDATE customers
        SET customer_name=%s,
            mobile=%s,
            email=%s
        WHERE id=%s
    """

    cursor.execute(
        query,
        (
            request_body.get("customer_name"),
            request_body.get("mobile"),
            request_body.get("email"),
            request_body.get("id")
        )
    )

    conn.commit()

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Customer updated successfully"
        })
    }


# ✅ LOCAL TEST
if __name__ == "__main__":

    event = {
        "body": json.dumps({
            "id": 3,
            "customer_name": "Updated Kumar",
            "mobile": "9999999999",
            "email": "updated@test.com"
        })
    }

    print(lambda_handler(event, None))