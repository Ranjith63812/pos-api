import json
from database import get_connection


def lambda_handler(event, context):

    conn = get_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM customers"

    cursor.execute(query)

    customers = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({
            "data": customers
        }, default=str)
    }


# ✅ LOCAL TEST
if __name__ == "__main__":

    event = {}

    response = lambda_handler(event, None)

    print(response)