import json
from database import get_connection


def delete_product_category_api(event, context):

    request_body = json.loads(event["body"])

    if not request_body.get("id"):
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Category id required"})
        }

    conn = get_connection()
    cursor = conn.cursor()

    try:

        query = "DELETE FROM product_categories WHERE id=%s"

        cursor.execute(query, (request_body.get("id"),))

        conn.commit()

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Product category deleted successfully"
            })
        }

    except Exception as e:

        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

    finally:
        cursor.close()
        conn.close()


def lambda_handler(event, context):
    return delete_product_category_api(event, context)

if __name__ == "__main__":

    event = {
        "body": json.dumps({
            "id": 3
        })
    }

    response = delete_product_category_api(event, None)
    print(response)