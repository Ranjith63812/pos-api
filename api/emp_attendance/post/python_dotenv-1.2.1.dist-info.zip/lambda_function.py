import json
from database import get_connection


def mark_attendance_api(event, context):

    request_body = json.loads(event["body"])

    if not request_body.get("office_id"):
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Office id required"})
        }

    if not request_body.get("emp_id"):
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Employee id required"})
        }

    if not request_body.get("status"):
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Status required"})
        }

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        INSERT INTO attendance (office_id, emp_id, status)
        VALUES (%s, %s, %s)
    """

    cursor.execute(query, (
        request_body.get("office_id"),
        request_body.get("emp_id"),
        request_body.get("status")
    ))

    conn.commit()

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Attendance marked successfully"})
    }

# Local Test
if __name__ == "__main__":

    event = {
        "body": json.dumps({
            "office_id": 1,
            "emp_id": 1,
            "status": "Present"
        })
    }

    response = mark_attendance_api(event, None)
    print(response)