import json
from database import get_connection


def lambda_handler(event, context):

    conn = get_connection()
    cursor = conn.cursor()   # DictCursor assumed

    query_params = event.get("queryStringParameters")

    # ==================================================
    # ✅ GET CATEGORY BY ID
    # ==================================================
    if query_params and query_params.get("id"):

        category_id = query_params.get("id")

        query = """
            SELECT id, category_name, description, status
            FROM expense_categories
            WHERE id = %s
        """

        cursor.execute(query, (category_id,))
        row = cursor.fetchone()

        if not row:
            cursor.close()
            conn.close()

            return {
                "statusCode": 404,
                "body": json.dumps({
                    "message": "Category not found"
                })
            }

        data = row   # already dictionary ✅

    # ==================================================
    # ✅ GET ALL CATEGORIES
    # ==================================================
    else:

        query = """
            SELECT id, category_name, description, status
            FROM expense_categories
        """

        cursor.execute(query)
        data = cursor.fetchall()   # list of dictionaries ✅

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({
            "data": data
        }, default=str)
    }


# ==================================================
# ✅ LOCAL TESTING (VS CODE)
# ==================================================
if __name__ == "__main__":

    # ✅ TEST 1 — GET ALL
    event_all = {
        "queryStringParameters": None
    }

    print("\n===== GET ALL =====")
    print(lambda_handler(event_all, None))

    # ✅ TEST 2 — GET BY ID
    event_by_id = {
        "queryStringParameters": {
            "id": "1"
        }
    }

    print("\n===== GET BY ID =====")
    print(lambda_handler(event_by_id, None))