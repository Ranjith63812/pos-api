import json
from database import get_connection


def lambda_handler(event, context):

    # ✅ Read request body
    request_body = json.loads(event.get("body", "{}"))
    category_id = request_body.get("id")

    # ✅ Validation
    if not category_id:
        return {
            "statusCode": 400,
            "body": json.dumps({
                "message": "Category id required"
            })
        }

    conn = get_connection()
    cursor = conn.cursor()

    # =====================================
    # ✅ CHECK CATEGORY USED IN EXPENSES
    # =====================================
    check_query = """
        SELECT COUNT(*) AS count
        FROM expenses
        WHERE category_id=%s
    """

    cursor.execute(check_query, (category_id,))
    result = cursor.fetchone()

    if result["count"] > 0:
        cursor.close()
        conn.close()

        return {
            "statusCode": 400,
            "body": json.dumps({
                "message": "Category already used in expenses"
            })
        }

    # =====================================
    # ✅ HARD DELETE
    # =====================================
    delete_query = """
        DELETE FROM expense_categories
        WHERE id=%s
    """

    cursor.execute(delete_query, (category_id,))
    conn.commit()

    if cursor.rowcount == 0:
        cursor.close()
        conn.close()

        return {
            "statusCode": 404,
            "body": json.dumps({
                "message": "Category not found"
            })
        }

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Category deleted successfully"
        })
    }


# =====================================
# ✅ LOCAL TEST (VS CODE)
# =====================================
if __name__ == "__main__":

    event = {
        "body": json.dumps({
            "id": 3
        })
    }

    print(lambda_handler(event, None))